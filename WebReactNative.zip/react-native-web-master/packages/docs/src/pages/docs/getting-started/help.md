---
title: Help
date: Last Modified
permalink: /docs/help/index.html
description: 
eleventyNavigation:
  key: Help
  parent: Start
  order: 5
---

:::lead
Questions? Looking for help? These are the best places to look first.
:::

## Discussions

[{{ site.name }} Discussions on GitHub]({{ site.githubUrl }}/discussions) is the place for general questions, discussions, and ideas.

## Issues

[{{ site.name }} Issues on GitHub]({{ site.githubUrl }}/issues) is the place for reporting and resolving issues with {{ site.name }}.
