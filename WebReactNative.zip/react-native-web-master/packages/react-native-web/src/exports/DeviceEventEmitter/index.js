import RCTDeviceEventEmitter from '../../vendor/react-native/NativeEventEmitter/RCTDeviceEventEmitter';
export default RCTDeviceEventEmitter;
