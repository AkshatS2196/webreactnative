// flow-typed signature: 121e589c9be7dac408c14a02e88287fa
// flow-typed version: a1a20d4928/create-react-class_v15.x.x/flow_>=v0.41.x

declare module 'create-react-class' {
  declare var exports: React$CreateClass;
}
